<?php
require_once './db_connect.php';
require_once './functions.php';


if (isset($_POST['function'])) {
  if (isset($_POST['name'])) {
    $response = null;
    switch ($_POST['function']) {
      case 'goThroughFile':
        $csvFile = __DIR__ . '/txt/yob2014.txt';
        $csv = readCSV($csvFile);
        foreach ($csv as $index => $babyname) {
          addBabyName($db, $babyname[0], $babyname[1], $babyname[2]);
        }
        break;

      case 'searchBabyName':
        $response = searchBabyName($db, $_POST['name']);
        break;

      case 'seedBabyNamesTable':
        seedBabyNamesTable($db);
        break;

      case 'createBabyTable':
        createBabyTable($db);
        break;

      case 'deleteBabyTable':
        deleteBabyTable($db);
        break;

      default:
        # code...
        break;
    }
    echo json_encode($response);
  }
}
?>